package com.company;

public class Car extends Vehicule{
    private int year;
    private String color;

    public Car(String name, String model, String engine, int doors, int wheels, int year, String color) {
        super(name, model, engine, doors, wheels);
        this.year = year;
        this.color = color;
    }

    public int getYear() {
        return year;
    }

    public String getColor() {
        return color;
    }
    public void handSteering(String side){
        System.out.println("The steering is " + side);

    }
    public void changeGear(int gear){
        System.out.println("Shift gear to " + gear);

    }

    @Override
    public void moving(int speed) {
        super.moving(speed);
    }

}
