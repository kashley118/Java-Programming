package com.company;

public class Vehicule {
    private String name;
    private String model;
    private String engine;
    private int doors;
    private int wheels;

    public Vehicule(String name, String model, String engine, int doors, int wheels) {
        this.name = name;
        this.model = model;
        this.engine = engine;
        this.doors = doors;
        this.wheels = wheels;
    }

    public String getName() {
        return name;
    }

    public String getModel() {
        return model;
    }

    public String getEngine() {
        return engine;
    }

    public int getDoors() {
        return doors;
    }

    public int getWheels() {
        return wheels;
    }
    public void moving(int speed){
        System.out.println("The vehicule is moving at " + speed + " speed");
    }
}

