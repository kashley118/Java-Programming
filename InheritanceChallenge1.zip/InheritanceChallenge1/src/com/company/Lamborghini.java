package com.company;

public class Lamborghini extends Car {
    private String size;

    public Lamborghini(String name, String model, String engine, int doors, int wheels, int year, String color, String size) {
        super(name, model, engine, doors, wheels, year, color);
        this.size = size;
    }
    public String getSize(){
        return this.size;
    }

}
