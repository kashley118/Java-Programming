package com.company;

public class Main {

    public static void main(String[] args) {
	// write your code here
       // Car car1 = new Car("Lamborghini", "Urus", "Automatic",4, 4, 2022, "Black");
        Lamborghini lambo1 = new Lamborghini("Lamborghini", "Urus","Automatic", 4, 4,
                2022, "Black", "SUV");
        System.out.println("The car name is "+ lambo1.getName());
        System.out.println("The car model is " + lambo1.getModel());
        System.out.println("The engine is " +lambo1.getEngine());
        System.out.println("The color is " + lambo1.getColor());
        System.out.println("The year is " +lambo1.getYear());
        System.out.println("The size is " + lambo1.getSize());
        lambo1.changeGear(3);
        lambo1.moving(120);
        lambo1.handSteering("Right");
    }
}
