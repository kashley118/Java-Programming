package com.company;

import java.util.Arrays;
import java.util.Scanner;

public class Main {
    private static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
	// write your code here
        int [] myArr = readIntegers(4);
        //int minArray = findMin(myArr);
        System.out.println("The value of minimum element is " + findMin(myArr));
    }
    public static int [] readIntegers(int count){

        System.out.println("Enter " + count + " values");
        int [] values = new int[count];
        for(int i = 0; i < values.length; i++){
            values[i] = scanner.nextInt();
        }
         return values;
    }

    public static int findMin(int [] arr){
        int [] minArr = new int [arr.length];
        int minNum = 0;

       minArr = Arrays.copyOf(arr, arr.length);
        for(int i = 0; i< minArr.length -1; i++){

            if(minArr[0] < minArr[i+1]){
                minArr[i] = minArr[0];
                minNum = minArr[i];

            }
            minArr[i + 1] = minArr[0];
            minNum = minArr[i+1];


        }


        return minNum;

    }




    }

