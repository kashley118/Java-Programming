package com.company;

public class Main {

    public static void main(String[] args) {
	// write your code here
        VipCustomer customer1 = new VipCustomer();
        VipCustomer customer2 = new VipCustomer("Kadi", 5000.00);
        VipCustomer customer3 = new VipCustomer("Olivia", 15000.00, "olivia@gmail.com");
        System.out.println("The 1st vip customer name: " + customer1.getName());
        System.out.println("The 1st vip customer credit limit " + customer1.getCreditLimit());
        System.out.println("The 1st customer email address is " + customer1.getEmail());
        System.out.println("\nThe 2st vip customer name: " + customer2.getName());
        System.out.println("The 2st vip customer credit limit " + customer2.getCreditLimit());
        System.out.println("The 2st customer email address is " + customer2.getEmail());

        System.out.println("\nThe 3st vip customer name: " + customer3.getName());
        System.out.println("The 3st vip customer credit limit " + customer3.getCreditLimit());
        System.out.println("The 3st customer email address is " + customer3.getEmail());
    }
}
