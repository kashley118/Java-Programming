package com.company;

public class Main {

    public static void main(String[] args) {
	// write your code here
        Hamburger hamburger = new Hamburger("Regular burger", "beef", 3.50, "White roll");
        hamburger.addHamburgerAddition1("tomatoes", 0.50);
        hamburger.addHamburgerAddition2("lettuce", 0.50);
        hamburger.addHamburgerAddition3("Eggs", 1.00);
        hamburger.addHamburgerAddition4("avocado", 1.50);
        System.out.println("The total for your burger is $" + hamburger.itemizeHamburger());
        DeluxeBurger deluxe = new DeluxeBurger();
        System.out.println("The total for your burger is $" + deluxe.itemizeHamburger());
        deluxe.addHamburgerAddition1("Avocado", 1.50);
        HealthyBurger healthy = new HealthyBurger("Veggie", 8.50);
        healthy.addHealthyAddition1("Avocado", 1.50);
        System.out.println("The total for your burger is $" + healthy.itemizeHamburger());






    }
}
