package com.company;

public class Hamburger {
    private String name;
    private String meat;
    private double price;
    private String breadRollType;
    private String addition1Name;
    private String addition2Name;
    private String addition3Name;
    private String addition4Name;
    private double addition1Price;
    private double addition2Price;
    private double addition3Price;
    private double addition4Price;


    public Hamburger(String name, String meat, double price, String breadRollType){
        this.name = name;
        this.meat = meat;
        this.price = price;
        this.breadRollType = breadRollType;
        this.addition1Name = addition1Name;
        this.addition2Name = addition2Name;
        this.addition3Name = addition3Name;
        this.addition4Name = addition4Name;
        //this.addition1Price = addition1Price;
        //this.addition2Price = addition2Price;
        //this.addition3Price = addition3Price;
        //this.addition4Price = addition4Price;

        System.out.println("Basic burger on " + breadRollType + " with " + meat + ", price is " + price);

    }
    public void addHamburgerAddition1(String name, double price){
        this.addition1Name = name;
        this.price += price;
        System.out.println("Added "+ addition1Name + " for an extra " + price);


    }
    public void addHamburgerAddition2(String name, double price){
        this.addition2Name = name;
        this.price += price;
        System.out.println("Added "+ addition2Name + " for an extra " + price);

    }
    public void addHamburgerAddition3(String name, double price){
        this.addition3Name = name;
        this.price += price;
        System.out.println("Added "+ addition3Name + " for an extra " + price);

    }
    public void addHamburgerAddition4(String name, double price){
        this.addition4Name = name;
        this.price += price;
        System.out.println("Added "+ addition4Name + " for an extra " + price);

    }

    public double itemizeHamburger(){
        return price;
    }

}
