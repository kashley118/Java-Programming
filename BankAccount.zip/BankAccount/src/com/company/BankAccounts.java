package com.company;

public class BankAccounts {
    private int accountNumber;
    private double balance;
    private String customerName;
    private String email;
    private String phoneNumber;

    public void setBankingInfo(int accountNumber, double balance, String customerName, String email,
                               String phoneNumber){
        this.accountNumber = accountNumber;
        this.balance = balance;
        this.customerName = customerName;
        this.email = email;
        this.phoneNumber = phoneNumber;
    }
    public int getAccountNumber(){
        return this.accountNumber;
    }
    public double getBalance(){
        return this.balance;
    }
    public String getCustomerName(){
        return this.customerName;
    }
    public String getEmail(){
        return this.email;
    }
    public String getPhoneNumber(){
        return this.phoneNumber;
    }
    public void setDeposit(double newBalance){
        this.balance = balance + newBalance;
        System.out.println("You have deposited "+ newBalance + ". Your new balance "+ this.balance);
    }

    public void setRemainingBalance(double balance) {
        if (this.balance < balance) {
            System.out.println("Insufficient funds. You can only withdrawal  " + balance);

        } else {
            this.balance = this.balance - balance;
            System.out.println("The remaining balance is " + this.balance);

        }
    }

}
