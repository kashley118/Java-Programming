package com.company;

public class Main {

    public static void main(String[] args) {
	// write your code here
        BankAccounts account1 = new BankAccounts();
        account1.setBankingInfo(123456, 5000000, "Kadiatou Balde",
                "kadiatoubalde118@gmail.com", "(416)-831-6742");
        System.out.println("Account # is " + account1.getAccountNumber());
        System.out.println("Balance is $" + account1.getBalance());
        System.out.println("Name is " + account1.getCustomerName());
        System.out.println("Email is " + account1.getEmail());
        System.out.println("Phone # is " + account1.getPhoneNumber());
        account1.setDeposit(2500);
        account1.setRemainingBalance(2500);

    }
}
