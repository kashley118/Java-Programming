package com.company;

public class Main {

    public static void main(String[] args) {
	// write your code here
        Printer printer = new Printer(50, false);
        System.out.print(printer.addToner(12));
        System.out.println("\nThe number of pages printed is " + printer.getPagesPrinted());
        int pagesPrinted = printer.printPages(4);
        System.out.println("The number of printed pages was " + pagesPrinted +" the new pages printed is = " +
                printer.getPagesPrinted());
        pagesPrinted = printer.printPages(2);
        System.out.println("The number of printed pages was " + pagesPrinted +" the new pages printed is = " +
                printer.getPagesPrinted());


    }
}
